-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: homestead
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classrooms`
--

DROP TABLE IF EXISTS `classrooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classrooms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classrooms`
--

LOCK TABLES `classrooms` WRITE;
/*!40000 ALTER TABLE `classrooms` DISABLE KEYS */;
INSERT INTO `classrooms` VALUES (16,'SS101','2017-03-31 07:46:43','2017-04-25 23:45:03'),(17,'ST436','2017-03-31 07:46:43','2017-03-31 07:46:43'),(19,'C108','2017-03-31 07:46:43','2017-03-31 07:46:43'),(21,'H208','2017-04-07 04:01:34','2017-04-07 04:01:34'),(22,'H306','2017-04-07 04:02:42','2017-04-07 04:02:42'),(23,'H307','2017-04-07 04:02:42','2017-04-07 04:02:42'),(24,'H304','2017-04-07 04:02:42','2017-04-07 04:02:42'),(25,'H305','2017-04-07 04:02:43','2017-04-07 04:02:43'),(26,'H318','2017-04-07 04:02:43','2017-04-25 20:14:11'),(35,'C101','2017-05-19 14:42:01','2017-05-19 14:42:01'),(36,'C102','2017-05-19 15:01:40','2017-05-19 15:01:40'),(37,'C103','2017-05-19 15:01:43','2017-05-19 15:01:43'),(38,'ST010','2017-05-19 15:01:49','2017-05-19 15:01:49'),(39,'ST011','2017-05-19 15:01:57','2017-05-19 15:01:57'),(40,'ST012','2017-05-19 15:02:01','2017-05-19 15:02:01'),(41,'ST021','2017-05-19 15:02:06','2017-05-19 15:02:06'),(42,'C215','2017-05-19 15:02:11','2017-05-19 15:02:11'),(43,'E201','2017-05-19 15:06:04','2017-05-19 15:06:04'),(44,'X001','2017-05-19 15:33:17','2017-05-19 15:33:17');
/*!40000 ALTER TABLE `classrooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_bases`
--

DROP TABLE IF EXISTS `course_bases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_bases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_bases`
--

LOCK TABLES `course_bases` WRITE;
/*!40000 ALTER TABLE `course_bases` DISABLE KEYS */;
INSERT INTO `course_bases` VALUES (1,'N/A','2017-05-18 00:18:09','2017-05-18 00:18:09'),(8,'離散數學','2017-03-31 07:45:40','2017-03-31 07:45:40'),(9,'機率與統計','2017-03-31 07:45:40','2017-03-31 07:45:40'),(10,'線性代數','2017-03-31 07:45:40','2017-03-31 07:45:40'),(11,'計算機組織','2017-03-31 07:45:40','2017-03-31 07:45:40'),(12,'演算法','2017-03-31 07:45:40','2017-03-31 07:45:40'),(13,'生命與生活','2017-03-31 07:45:40','2017-03-31 07:45:40'),(14,'作業系統','2017-03-31 07:45:40','2017-03-31 07:45:40'),(15,'資料結構','2017-03-31 07:45:40','2017-03-31 07:45:40'),(16,'微積分','2017-04-02 16:01:31','2017-04-02 16:01:31'),(17,'高等微積分','2017-04-02 16:01:31','2017-04-02 16:01:31'),(18,'文學概論','2017-04-07 04:03:34','2017-04-07 04:03:34'),(19,'中國文學史','2017-04-07 04:04:36','2017-04-07 04:04:36'),(20,'詩選及習作','2017-04-07 04:04:36','2017-04-07 04:04:36'),(21,'文字學','2017-04-07 04:04:36','2017-04-07 04:04:36'),(22,'聲韻學','2017-04-07 04:04:36','2017-04-07 04:04:36'),(23,'歷代文選及習作','2017-04-07 04:04:36','2017-04-07 04:04:36'),(24,'史記','2017-05-07 23:15:25','2017-05-07 23:15:25'),(25,'清史','2017-05-07 23:15:36','2017-05-07 23:15:36'),(28,'戲劇賞析','2017-05-08 00:49:28','2017-05-08 00:49:28'),(29,'劇本寫作','2017-05-08 00:49:33','2017-05-08 00:49:33'),(30,'普通化學','2017-05-08 00:51:21','2017-05-08 00:51:21'),(31,'有機化學實驗','2017-05-08 00:51:31','2017-05-08 00:51:31'),(32,'物理化學','2017-05-08 00:51:40','2017-05-08 00:51:40'),(33,'物理化學實驗','2017-05-08 00:51:43','2017-05-08 00:51:43'),(34,'儀器分析實驗','2017-05-08 00:51:50','2017-05-08 00:51:50'),(88,'創業方法論','2017-05-19 14:35:07','2017-05-19 14:35:07'),(89,'計算機概論','2017-05-19 14:45:02','2017-05-19 14:45:02'),(90,'電子電路學','2017-05-19 14:45:35','2017-05-19 14:45:35'),(91,'電子電路學實驗','2017-05-19 14:45:59','2017-05-19 14:45:59'),(92,'C程式設計與實作','2017-05-19 14:46:32','2017-05-19 14:46:32'),(93,'普通物理','2017-05-19 14:47:12','2017-05-19 14:47:12'),(94,'專題實作','2017-05-19 14:54:46','2017-05-19 14:54:46'),(95,'資料庫','2017-05-19 14:55:03','2017-05-19 14:55:03'),(96,'JAVA程式設計','2017-05-19 14:56:03','2017-05-19 14:56:03'),(97,'邏輯設計','2017-05-19 14:56:50','2017-05-19 14:56:50'),(98,'系統程式與組合語言','2017-05-19 14:57:06','2017-05-19 14:57:06'),(99,'邏輯設計實驗','2017-05-19 14:57:18','2017-05-19 14:57:18'),(100,'計算機網路','2017-05-19 14:57:38','2017-05-19 14:57:38'),(101,'嵌入式系統導論','2017-05-19 14:57:52','2017-05-19 14:57:52'),(102,'程式語言','2017-05-19 14:58:06','2017-05-19 14:58:06'),(103,'機率統計','2017-05-19 14:58:39','2017-05-19 14:58:39'),(104,'科技英文閱讀寫作','2017-05-19 14:59:05','2017-05-19 14:59:05'),(105,'編譯器','2017-05-19 14:59:15','2017-05-19 14:59:15'),(106,'進階資料結構','2017-05-19 14:59:28','2017-05-19 14:59:28'),(107,'軟體工程','2017-05-19 14:59:47','2017-05-19 14:59:47'),(108,'物件導向程設計','2017-05-19 15:00:10','2017-05-19 15:00:10'),(109,'專題研究','2017-05-19 15:00:21','2017-05-19 15:00:21'),(110,'網際網路創新應用','2017-05-19 15:00:31','2017-05-19 15:00:31');
/*!40000 ALTER TABLE `course_bases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_professors`
--

DROP TABLE IF EXISTS `course_professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_professors` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `course_professors_ibfk_1` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_professors`
--

LOCK TABLES `course_professors` WRITE;
/*!40000 ALTER TABLE `course_professors` DISABLE KEYS */;
INSERT INTO `course_professors` VALUES (45,16,2,'2017-04-02 11:49:42','2017-04-02 11:49:42'),(46,18,5,'2017-04-05 04:23:15','2017-04-05 04:23:15'),(47,20,4,'2017-04-05 07:56:26','2017-04-05 07:56:26'),(48,19,2,'2017-04-05 07:56:35','2017-04-05 07:56:35'),(49,17,2,'2017-04-06 08:13:10','2017-04-06 08:13:10'),(50,21,8,'2017-04-07 04:23:39','2017-04-07 04:23:39'),(51,23,10,'2017-04-07 04:23:39','2017-04-07 04:23:39'),(52,22,9,'2017-04-07 04:23:39','2017-04-07 04:23:39'),(53,24,11,'2017-04-07 04:23:39','2017-04-07 04:23:39'),(54,25,12,'2017-04-07 04:23:39','2017-04-07 04:23:39'),(55,26,13,'2017-04-07 04:23:39','2017-04-07 04:23:39'),(79,40,4,'2017-05-19 14:25:19','2017-05-19 14:25:19'),(80,44,61,'2017-05-20 03:05:47','2017-05-20 03:05:47'),(81,45,2,'2017-05-20 03:06:02','2017-05-20 03:06:02');
/*!40000 ALTER TABLE `course_professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_times`
--

DROP TABLE IF EXISTS `course_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_times` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned NOT NULL,
  `day_id` int(10) unsigned NOT NULL,
  `period_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `period_id` (`period_id`),
  KEY `day_id` (`day_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_times`
--

LOCK TABLES `course_times` WRITE;
/*!40000 ALTER TABLE `course_times` DISABLE KEYS */;
INSERT INTO `course_times` VALUES (82,17,3,7,'2017-04-06 06:39:37','2017-05-18 08:22:22'),(83,17,3,8,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(84,18,2,6,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(85,18,2,7,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(86,19,5,3,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(87,19,5,4,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(88,20,4,6,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(89,20,4,7,'2017-04-06 06:39:37','2017-04-06 06:39:37'),(90,22,2,3,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(91,22,2,4,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(92,22,2,2,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(93,23,4,7,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(94,23,4,6,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(95,24,5,5,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(96,24,5,6,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(97,25,3,6,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(98,25,3,7,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(99,26,2,6,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(100,26,2,7,'2017-04-07 04:26:50','2017-04-07 04:26:50'),(102,18,1,3,'2017-04-13 07:27:10','2017-04-13 07:27:10'),(103,21,1,3,'2017-04-13 07:27:10','2017-04-13 07:27:10'),(104,21,1,4,'2017-04-13 07:27:47','2017-04-13 07:27:47'),(105,16,3,12,'2017-04-13 09:13:18','2017-04-13 09:13:18'),(106,16,3,13,'2017-04-13 09:13:18','2017-04-13 09:13:18'),(107,16,3,14,'2017-04-13 09:13:18','2017-04-13 09:13:18'),(185,40,1,2,'2017-05-19 14:25:53','2017-05-19 14:25:53'),(186,40,1,3,'2017-05-19 14:26:29','2017-05-19 14:26:29'),(187,40,1,4,'2017-05-19 14:26:40','2017-05-19 14:26:40'),(188,44,2,2,'2017-05-20 03:00:23','2017-05-20 03:00:23'),(189,44,2,3,'2017-05-20 03:00:38','2017-05-20 03:00:38'),(190,44,2,4,'2017-05-20 03:00:49','2017-05-20 03:00:49'),(191,45,3,2,'2017-05-20 03:01:41','2017-05-20 03:01:41'),(192,45,5,2,'2017-05-20 03:01:58','2017-05-20 03:01:58'),(193,45,5,3,'2017-05-20 03:02:14','2017-05-20 03:02:14'),(194,45,5,4,'2017-05-20 03:02:22','2017-05-20 03:02:22'),(195,46,2,3,'2017-05-20 03:03:12','2017-05-20 03:03:12'),(198,46,2,4,'2017-05-20 03:04:10','2017-05-20 03:04:10'),(199,46,3,2,'2017-05-20 03:04:31','2017-05-20 03:04:31');
/*!40000 ALTER TABLE `course_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_types`
--

DROP TABLE IF EXISTS `course_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `unit_id` (`unit_id`),
  KEY `type_id` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_types`
--

LOCK TABLES `course_types` WRITE;
/*!40000 ALTER TABLE `course_types` DISABLE KEYS */;
INSERT INTO `course_types` VALUES (36,16,8,9,'2017-04-02 11:48:21','2017-04-02 11:48:21'),(38,21,8,11,'2017-04-07 04:30:01','2017-04-07 04:30:01'),(39,21,9,2,'2017-04-07 04:30:01','2017-04-07 04:30:01'),(40,22,8,11,'2017-04-07 04:30:01','2017-04-07 04:30:01'),(41,22,9,2,'2017-04-07 04:30:01','2017-04-07 04:30:01'),(42,23,8,11,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(43,23,9,2,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(44,24,8,11,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(45,24,9,2,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(46,25,9,2,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(47,25,8,10,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(48,26,8,11,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(49,26,9,2,'2017-04-07 04:32:46','2017-04-07 04:32:46'),(50,17,9,11,'2017-04-13 09:11:01','2017-04-13 09:11:01'),(51,17,9,2,'2017-04-13 09:11:01','2017-04-13 09:11:01'),(52,18,8,9,'2017-04-13 09:11:30','2017-04-13 09:11:30'),(53,18,9,2,'2017-04-13 09:11:30','2017-04-13 09:11:30'),(54,19,8,9,'2017-04-13 09:12:04','2017-04-13 09:12:04'),(55,19,9,2,'2017-04-13 09:12:04','2017-04-13 09:12:04'),(56,20,8,9,'2017-04-13 09:12:04','2017-04-13 09:12:04'),(57,20,9,2,'2017-04-13 09:12:04','2017-04-13 09:12:04'),(59,16,9,2,'2017-04-13 09:12:34','2017-05-18 08:49:02'),(66,40,8,9,'2017-05-19 14:28:19','2017-05-19 14:28:19'),(67,44,8,9,'2017-05-20 03:07:40','2017-05-20 03:07:40'),(68,46,8,9,'2017-05-20 03:07:56','2017-05-20 03:07:56');
/*!40000 ALTER TABLE `course_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `course_base_id` int(10) unsigned NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `classroom_id` int(10) unsigned NOT NULL,
  `credit` int(10) unsigned NOT NULL,
  `language` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '中文',
  `year` year(4) NOT NULL,
  `semester` int(1) NOT NULL,
  `enrollment_remain` int(10) unsigned NOT NULL DEFAULT '0',
  `enrollment_max` int(10) unsigned NOT NULL,
  `enroll` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `credit` (`credit`),
  KEY `language` (`language`),
  KEY `enrollment_can` (`enroll`),
  KEY `courses_ibfk_1` (`course_base_id`),
  KEY `courses_ibfk_2` (`unit_id`),
  KEY `courses_ibfk_3` (`classroom_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (16,'作業系統',14,9,17,3,'中文',2016,1,54,65,0,'2017-04-02 11:35:18','2017-05-20 15:00:07',NULL),(17,'生命與生活',13,10,16,2,'中文',2017,1,13,20,0,'2017-04-02 11:56:42','2017-05-20 14:55:43',NULL),(18,'計算機組織',11,9,19,3,'英文',2016,1,58,60,0,'2017-04-02 14:56:01','2017-05-20 14:55:47',NULL),(19,'線性代數',10,8,17,3,'中文',2017,2,0,50,0,'2017-04-02 14:57:25','2017-05-09 00:56:43',NULL),(20,'高等微積分',17,8,19,3,'中文',2016,1,48,50,0,'2017-04-02 16:05:52','2017-05-20 14:55:51',NULL),(21,'文學概論',18,10,26,2,'中文',2016,2,49,50,0,'2017-04-07 04:16:07','2017-05-20 14:55:58',NULL),(22,'中國文學史',19,11,25,3,'中文',2016,2,59,60,0,'2017-04-07 04:18:35','2017-05-20 14:56:02',NULL),(23,'詩選及習作',20,11,25,2,'中文',2016,2,40,40,0,'2017-04-07 04:18:35','2017-05-20 14:58:19',NULL),(24,'文字學',21,12,19,2,'中文',2016,2,50,51,0,'2017-04-07 04:18:35','2017-05-20 14:56:10',NULL),(25,'聲韻學',22,11,22,2,'中文',2016,1,45,45,0,'2017-04-07 04:20:21','2017-05-20 14:58:29',NULL),(26,'歷代文選及習作',23,11,24,2,'中文',2016,1,45,45,0,'2017-04-07 04:20:21','2017-05-20 14:58:33',NULL),(27,'史記',24,12,23,2,'英文',2017,1,30,30,0,'2017-05-07 23:16:18','2017-05-20 14:58:38',NULL),(28,'清史',25,12,26,3,'英文',2017,1,32,32,0,'2017-05-07 23:20:24','2017-05-20 14:58:41',NULL),(29,'物理化學',32,15,23,3,'英文',2017,1,48,48,0,'2017-05-08 00:52:18','2017-05-20 14:58:45',NULL),(30,'有機化學實驗',31,15,25,3,'英文',2017,1,44,44,0,'2017-05-08 00:52:40','2017-05-20 14:58:49',NULL),(31,'普通化學',30,15,22,3,'中文',2017,1,30,30,0,'2017-05-08 00:53:07','2017-05-20 14:58:53',NULL),(32,'儀器分析實驗',34,15,22,3,'英文',2017,1,30,30,0,'2017-05-08 00:53:26','2017-05-20 14:58:57',NULL),(40,'電子電路學實驗',91,9,19,1,'中文',2017,1,50,50,0,'2017-05-19 14:21:08','2017-05-19 15:19:34','2017-05-19 15:19:34'),(41,'創業方法論',88,8,16,3,'中文',2016,1,50,50,0,'2017-05-19 14:35:35','2017-05-20 14:59:01',NULL),(42,'計算機概論',89,9,38,3,'中文',2017,1,50,50,0,'2017-05-19 15:03:52','2017-05-20 14:59:05',NULL),(43,'電子電路學',90,9,35,3,'中文',2017,1,50,50,0,'2017-05-19 15:08:10','2017-05-20 14:59:10',NULL),(44,'電子電路學實驗',91,9,43,1,'英文',2017,1,60,60,0,'2017-05-19 15:09:12','2017-05-19 15:09:12',NULL),(45,'C程式設計與實作',92,9,41,3,'中文',2017,1,60,60,0,'2017-05-19 15:10:59','2017-05-19 15:10:59',NULL),(46,'普通物理',93,8,42,2,'英文',2017,1,30,30,0,'2017-05-19 15:12:36','2017-05-20 14:59:24',NULL),(47,'專題實作',94,9,35,2,'中文',2016,1,50,50,0,'2017-05-19 15:13:48','2017-05-19 15:13:48',NULL),(48,'專題研究',109,9,35,2,'中文',2017,2,50,50,0,'2017-05-19 15:14:25','2017-05-19 15:14:25',NULL),(49,'資料庫',95,9,39,3,'中文',2017,1,50,50,0,'2017-05-19 15:16:11','2017-05-19 15:16:11',NULL),(50,'JAVA程式設計',96,9,40,3,'中文',2017,2,60,60,0,'2017-05-19 15:16:35','2017-05-19 15:16:35',NULL),(51,'邏輯設計',97,9,36,3,'中文',2017,2,58,58,0,'2017-05-19 15:17:21','2017-05-19 15:17:21',NULL),(52,'系統程式與組合語言',98,9,36,3,'中文',2017,1,60,60,0,'2017-05-19 15:18:20','2017-05-19 15:18:20',NULL),(53,'邏輯設計實驗',99,9,43,1,'中文',2017,2,60,60,0,'2017-05-19 15:18:44','2017-05-20 14:28:22',NULL),(54,'計算機網路',100,9,22,3,'中文',2017,1,60,60,0,'2017-05-19 15:20:28','2017-05-19 15:20:28',NULL),(55,'嵌入式系統導論',101,9,26,3,'中文',2017,1,40,40,0,'2017-05-19 15:20:55','2017-05-19 15:20:55',NULL),(56,'程式語言',102,9,17,3,'中文',2017,1,50,50,0,'2017-05-19 15:21:27','2017-05-19 15:21:27',NULL),(57,'機率統計',103,9,36,3,'中文',2017,1,50,50,0,'2017-05-19 15:21:49','2017-05-19 15:21:49',NULL),(58,'科技英文閱讀寫作',104,9,35,2,'英文',2017,1,50,50,0,'2017-05-19 15:22:13','2017-05-19 15:22:13',NULL),(59,'編譯器',105,9,39,3,'中文',2017,1,60,60,0,'2017-05-19 15:22:42','2017-05-19 15:22:42',NULL),(60,'進階資料結構',106,9,41,3,'中文',2017,2,70,70,0,'2017-05-19 15:23:21','2017-05-19 15:23:21',NULL),(61,'軟體工程',107,9,42,3,'中文',2017,1,55,55,0,'2017-05-19 15:23:50','2017-05-19 15:23:50',NULL),(62,'物件導向程設計',108,9,38,3,'英文',2017,1,40,40,0,'2017-05-19 15:24:16','2017-05-19 15:24:16',NULL),(63,'專題研究',109,9,35,2,'中文',2017,2,40,40,0,'2017-05-19 15:24:57','2017-05-19 15:24:57',NULL),(64,'網際網路創新應用',110,9,41,3,'中文',2017,1,55,55,0,'2017-05-19 15:25:31','2017-05-19 15:25:31',NULL),(65,'離散數學',8,9,36,3,'中文',2017,1,53,53,0,'2017-05-19 15:27:20','2017-05-19 15:27:20',NULL),(66,'機率與統計',9,17,21,3,'中文',2017,1,38,38,0,'2017-05-19 15:28:02','2017-05-19 15:28:02',NULL),(67,'演算法',12,9,42,3,'中文',2017,1,50,50,0,'2017-05-19 15:28:58','2017-05-19 15:28:58',NULL),(68,'資料結構',15,9,39,3,'中文',2017,1,50,50,0,'2017-05-19 15:29:46','2017-05-19 15:29:46',NULL),(69,'戲劇賞析',28,10,22,2,'中文',2017,1,70,70,0,'2017-05-19 15:31:25','2017-05-19 15:31:25',NULL),(70,'劇本寫作',29,10,22,2,'中文',2017,1,80,80,0,'2017-05-19 15:31:56','2017-05-19 15:31:56',NULL),(71,'物理化學實驗',33,15,44,1,'中文',2017,1,55,55,0,'2017-05-19 15:33:59','2017-05-19 15:33:59',NULL);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curricula`
--

DROP TABLE IF EXISTS `curricula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curricula` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `course_id` int(10) unsigned NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '預選中',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curricula`
--

LOCK TABLES `curricula` WRITE;
/*!40000 ALTER TABLE `curricula` DISABLE KEYS */;
INSERT INTO `curricula` VALUES (143,7,24,'預選中','2017-05-04 07:36:16','2017-05-04 07:36:16'),(148,7,21,'預選中','2017-05-07 22:39:29','2017-05-07 22:39:29'),(149,7,22,'預選中','2017-05-07 22:39:46','2017-05-07 22:39:46'),(150,7,16,'預選中','2017-05-07 22:42:49','2017-05-07 22:42:49'),(151,7,17,'預選中','2017-05-07 22:42:55','2017-05-07 22:42:55'),(154,7,18,'預選中','2017-05-07 22:43:44','2017-05-07 22:43:44'),(157,1,19,'預選中','2017-05-09 00:04:07','2017-05-09 00:04:07'),(159,1,18,'預選中','2017-05-09 08:00:45','2017-05-09 08:00:45'),(160,1,20,'預選中','2017-05-09 08:00:45','2017-05-09 08:00:45'),(161,1,16,'預選中','2017-05-11 01:09:04','2017-05-11 01:09:04'),(162,17,16,'預選中','2017-05-14 13:40:01','2017-05-14 13:40:01'),(169,28,17,'預選中','2017-05-15 09:46:58','2017-05-15 09:46:58'),(173,28,16,'預選中','2017-05-16 21:13:20','2017-05-16 21:13:20'),(175,28,18,'預選中','2017-05-18 08:55:17','2017-05-18 08:55:17'),(176,28,20,'預選中','2017-05-18 23:28:32','2017-05-18 23:28:32'),(177,28,21,'預選中','2017-05-19 04:34:13','2017-05-19 04:34:13'),(178,28,22,'預選中','2017-05-19 13:13:19','2017-05-19 13:13:19'),(179,19,17,'預選中','2017-05-19 13:53:00','2017-05-19 13:53:00');
/*!40000 ALTER TABLE `curricula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `days`
--

DROP TABLE IF EXISTS `days`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `days` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `simple_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `days`
--

LOCK TABLES `days` WRITE;
/*!40000 ALTER TABLE `days` DISABLE KEYS */;
INSERT INTO `days` VALUES (1,'星期一','一'),(2,'星期二','二'),(3,'星期三','三'),(4,'星期四','四'),(5,'星期五','五'),(6,'星期六','六');
/*!40000 ALTER TABLE `days` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `context` varchar(4096) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `his_apply_courses`
--

DROP TABLE IF EXISTS `his_apply_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `his_apply_courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `course_id` int(10) unsigned NOT NULL,
  `professor_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `his_apply_courses`
--

LOCK TABLES `his_apply_courses` WRITE;
/*!40000 ALTER TABLE `his_apply_courses` DISABLE KEYS */;
/*!40000 ALTER TABLE `his_apply_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `his_take_courses`
--

DROP TABLE IF EXISTS `his_take_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `his_take_courses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(10) unsigned NOT NULL,
  `course_id` int(10) unsigned NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_bin DEFAULT '預選中',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `his_take_courses`
--

LOCK TABLES `his_take_courses` WRITE;
/*!40000 ALTER TABLE `his_take_courses` DISABLE KEYS */;
INSERT INTO `his_take_courses` VALUES (11,1,16,'預選中','2017-04-04 09:26:28','2017-04-04 09:26:28'),(12,1,17,'預選中','2017-04-05 07:33:21','2017-04-05 07:33:21'),(13,1,19,'預選中','2017-04-04 09:27:11','2017-04-04 09:27:11'),(14,1,20,'預選中','2017-04-05 07:33:30','2017-04-05 07:33:30'),(15,7,21,'預選中','2017-04-07 04:28:31','2017-04-07 04:28:31'),(16,7,22,'預選中','2017-04-07 04:29:03','2017-04-07 04:29:03'),(17,7,23,'預選中','2017-04-07 04:29:03','2017-04-07 04:29:03'),(18,7,24,'預選中','2017-04-07 04:29:03','2017-04-07 04:29:03'),(19,7,25,'預選中','2017-04-07 04:29:03','2017-04-07 04:29:03'),(20,7,26,'預選中','2017-04-07 04:29:03','2017-04-07 04:29:03');
/*!40000 ALTER TABLE `his_take_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (3,'2014_10_12_000000_create_users_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('f1026115@thu.edu.tw','$2y$10$3sqKJu/1IuPtXHI8TNwsCOFzN/WIS.JYa/7jKZaiwFJ9FGjzx9aAO','2017-05-14 14:23:20');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `periods`
--

DROP TABLE IF EXISTS `periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `上課時間` time NOT NULL,
  `下課時間` time NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `上課時間` (`上課時間`),
  KEY `下課時間` (`下課時間`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periods`
--

LOCK TABLES `periods` WRITE;
/*!40000 ALTER TABLE `periods` DISABLE KEYS */;
INSERT INTO `periods` VALUES (1,'第一堂','07:10:00','08:00:00'),(2,'第二堂','08:10:00','09:00:00'),(3,'第三堂','09:10:00','10:00:00'),(4,'第四堂','10:20:00','11:10:00'),(5,'第五堂','11:20:00','12:10:00'),(6,'第六堂','12:10:00','13:00:00'),(7,'第七堂','13:10:00','14:00:00'),(8,'第八堂','14:10:00','15:00:00'),(9,'第九堂','15:20:00','16:10:00'),(10,'第十堂','16:20:00','17:10:00'),(11,'第十一堂','17:20:00','18:10:00'),(12,'第十二堂','18:20:00','19:10:00'),(13,'第十三堂','19:20:00','20:10:00'),(14,'第十四堂','20:20:00','21:10:00'),(15,'第十五堂','21:20:00','22:10:00');
/*!40000 ALTER TABLE `periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prerequisites`
--

DROP TABLE IF EXISTS `prerequisites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prerequisites` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `course_id` int(10) unsigned NOT NULL,
  `course_base_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `course_base_id` (`course_base_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prerequisites`
--

LOCK TABLES `prerequisites` WRITE;
/*!40000 ALTER TABLE `prerequisites` DISABLE KEYS */;
/*!40000 ALTER TABLE `prerequisites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professors`
--

DROP TABLE IF EXISTS `professors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professors` (
  `id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `skills` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professors`
--

LOCK TABLES `professors` WRITE;
/*!40000 ALTER TABLE `professors` DISABLE KEYS */;
INSERT INTO `professors` VALUES (2,'教授','人工智慧',9,'2017-04-02 11:49:32','2017-04-02 11:49:32',NULL),(4,'兼任教師','編譯器',9,'2017-05-19 15:04:58','2017-05-20 02:47:13',NULL),(5,'兼任教師','計算機組織',9,'2017-05-19 15:05:07','2017-05-20 02:17:55',NULL),(8,'13123213','12312312',11,'2017-04-07 04:13:19','2017-04-07 04:13:19',NULL),(9,'xcv13123213','1231df2312',11,'2017-04-07 04:14:30','2017-04-07 04:14:30',NULL),(10,'1312afds3213','1231sadf2312',11,'2017-04-07 04:14:30','2017-04-07 04:14:30',NULL),(11,'1312qw3213','12312xz312',11,'2017-04-07 04:14:30','2017-04-07 04:14:30',NULL),(12,'13123adsf213','1231xcv2312',11,'2017-04-07 04:14:30','2017-04-07 04:14:30',NULL),(13,'asfd1312df3213','123qr12312',11,'2017-04-07 04:14:30','2017-04-07 04:14:30',NULL),(14,'助理教授','嵌入式系統',11,'2017-04-07 04:14:31','2017-05-20 02:20:08',NULL),(15,'131232sdf13','12312sdf312',11,'2017-04-07 04:15:01','2017-04-07 04:15:01',NULL),(61,'副教授','人工智慧',9,'2017-05-20 02:14:46','2017-05-20 02:14:46',NULL),(62,'副教授','網路創意應用',9,'2017-05-20 02:16:15','2017-05-20 02:16:15',NULL),(63,'助理教授','大數據分析',9,'2017-05-20 02:24:17','2017-05-20 02:24:17',NULL),(64,'助理教授','雲端技術',9,'2017-05-20 02:25:27','2017-05-20 02:25:27',NULL),(65,'副教授','嵌入式互動系統',9,'2017-05-20 02:34:06','2017-05-20 02:34:06',NULL),(66,'副教授','訊息安全',9,'2017-05-20 02:36:07','2017-05-20 02:36:07',NULL),(67,'副教授','無線網路',9,'2017-05-20 02:37:11','2017-05-20 02:37:11',NULL),(68,'副教授','資訊管理',9,'2017-05-20 02:39:58','2017-05-20 02:39:58',NULL),(69,'助理教授級專業技術人員','軟體工程',9,'2017-05-20 02:48:46','2017-05-20 02:48:52',NULL),(70,'副教授','嵌入式系統',9,'2017-05-20 02:58:07','2017-05-20 02:58:07',NULL);
/*!40000 ALTER TABLE `professors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(10) unsigned NOT NULL,
  `year` year(4) NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_bin NOT NULL DEFAULT '在學',
  `unit_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,2013,'在學',9,'2017-04-02 10:56:35','2017-04-02 10:56:35',NULL),(7,2017,'在學',11,'2017-04-05 03:08:03','2017-04-05 03:08:03',NULL),(16,2013,'在學',9,'2017-05-14 13:22:29','2017-05-15 08:52:21',NULL),(17,2013,'在學',9,'2017-05-14 13:22:29',NULL,NULL),(18,2013,'在學',9,'2017-05-14 13:22:29',NULL,NULL),(19,2013,'在學',9,'2017-05-14 13:22:29',NULL,NULL),(20,2013,'在學',9,'2017-05-14 13:22:29',NULL,NULL),(23,2014,'在學',17,'2017-05-15 06:48:59',NULL,NULL),(24,2013,'在學',9,'2017-05-15 06:49:20',NULL,NULL),(28,2017,'在學',9,'2017-05-15 09:19:33','2017-05-15 09:19:33',NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value1` int(11) NOT NULL,
  `value2` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tests`
--

LOCK TABLES `tests` WRITE;
/*!40000 ALTER TABLE `tests` DISABLE KEYS */;
INSERT INTO `tests` VALUES (3,3,1,'2017-04-18 08:07:23','2017-05-12 08:12:23'),(4,2,3,'2017-04-18 08:07:28','2017-04-18 08:07:28'),(5,3,4,'2017-04-18 08:07:34','2017-04-18 08:07:34');
/*!40000 ALTER TABLE `tests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thresholds`
--

DROP TABLE IF EXISTS `thresholds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thresholds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` int(10) unsigned NOT NULL,
  `type_id` int(10) unsigned NOT NULL,
  `course_base_id` int(10) unsigned NOT NULL,
  `adopt_year` year(4) NOT NULL,
  `default_grade` int(2) unsigned NOT NULL,
  `default_semester` int(1) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unit_id` (`unit_id`),
  KEY `thresholds_ibfk_2` (`course_base_id`),
  KEY `type_id` (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thresholds`
--

LOCK TABLES `thresholds` WRITE;
/*!40000 ALTER TABLE `thresholds` DISABLE KEYS */;
INSERT INTO `thresholds` VALUES (1,8,8,16,2016,1,2,'2017-04-15 09:36:02','2017-05-19 04:37:19'),(2,8,8,8,2017,3,2,'2017-04-15 09:36:02','2017-04-27 22:08:01'),(3,9,8,15,2016,3,1,'2017-04-15 09:36:02','2017-04-27 21:12:05'),(4,8,8,10,2017,3,2,'2017-04-15 09:36:02','2017-04-15 09:36:02'),(5,8,9,14,2016,3,1,'2017-04-27 22:07:50','2017-04-27 22:07:50'),(6,11,8,18,2017,1,2,'2017-05-14 17:47:07','2017-05-14 17:47:07'),(7,11,8,19,2017,1,2,'2017-05-14 17:47:22','2017-05-14 17:47:22'),(8,11,8,23,2017,2,1,'2017-05-14 17:48:32','2017-05-14 17:48:32'),(9,15,8,30,2017,1,1,'2017-05-14 17:48:49','2017-05-14 17:48:49'),(10,15,7,31,2017,2,1,'2017-05-14 17:49:00','2017-05-14 17:49:00'),(11,9,7,9,2017,3,1,'2017-05-14 17:49:13','2017-05-14 17:49:13'),(12,9,8,12,2017,3,2,'2017-05-14 17:49:34','2017-05-14 17:49:34'),(25,9,8,15,2017,2,1,'2017-05-19 13:24:27','2017-05-19 13:24:27');
/*!40000 ALTER TABLE `thresholds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types`
--

DROP TABLE IF EXISTS `types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `subjection` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `subjection_2` (`subjection`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types`
--

LOCK TABLES `types` WRITE;
/*!40000 ALTER TABLE `types` DISABLE KEYS */;
INSERT INTO `types` VALUES (1,'通識','學校'),(2,'學校','學校'),(3,'通識人文','通識'),(4,'通識自然','通識'),(5,'通識社會','通識'),(6,'通識文明與經典','通識'),(7,'必選修','學校'),(8,'必修','學校'),(9,'選修','學校'),(10,'共選修','學校');
/*!40000 ALTER TABLE `types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `unit_base_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `unit_base_id` (`unit_base_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'全部',1,'2017-03-31 07:29:09','2017-05-07 23:10:39'),(2,'其餘',1,'2017-04-02 11:44:11','2017-05-07 22:52:22'),(8,'工學院',1,'2017-03-31 07:30:25','2017-03-31 07:30:25'),(9,'資工系',8,'2017-03-31 07:30:25','2017-03-31 07:30:25'),(10,'文學院',1,'2017-03-31 07:30:25','2017-03-31 07:30:25'),(11,'中文系',10,'2017-03-31 07:30:25','2017-05-07 22:53:08'),(12,'歷史系',10,'2017-03-31 07:30:25','2017-03-31 07:30:25'),(14,'理學院',1,'2017-05-08 00:50:56','2017-05-08 00:50:56'),(15,'化學系',14,'2017-05-08 00:51:07','2017-05-08 00:51:07'),(16,'商學院',1,'2017-05-15 06:46:35',NULL),(17,'國貿系',16,'2017-05-15 06:48:26','2017-05-15 09:02:26');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'chang','chang@thu.edu.tw','$2y$10$CF4UipcL5FTRSO.QUrz3TeoqiwqqfpBNZwLsONuowjb62W1b108a.','student','lpop5fEJZn3jkprRLnOiKvvPKn6gDKB2FE4tNmiFqDx7Wfji96wTpwFha8zX','2017-04-02 00:02:22','2017-05-18 23:48:31'),(2,'蔡清*','tsai@thu.edu.tw','$2y$10$8mFhp3z5nscWqC6BoBLG3O2q8Ib4zZbjh0yyJ/5amxWhUIZF4PWg6','professor','N7jSv5yCkA993zF79hrRxjgMVM3hvHuMqTTNadzYBy2PCbMjFmYjSvAvBtIf','2017-04-02 01:13:05','2017-04-02 01:13:05'),(3,'admin','admin@thu.edu.tw','$2y$10$bb2DVj70dDT9/uB0KI/02ug.qoidqTi3iNZVHV6UlRcYvTQtEJmXS','authority','nMivnkcfgxid2E6jF1eka7g1CYjo372mdNnXtekd4VzH4zqWVKFUVfzKg1WW','2017-04-02 01:19:24','2017-05-14 05:26:21'),(4,'張啟*','lu@thu.edu.tw','$2y$10$JyNaVwkiGKYFL7OCumzSTu5v96HYw7LZHG0Ik4i4OOFaGdK88tBFi','professor','qFEuSKeOJ3abqtpL6AJ9hBOli9a6G6xxN8nams9M0sBaYdQfHQz3wfwnXafH','2017-04-02 03:58:39','2017-04-02 03:58:39'),(5,'郭育*','kao@thu.edu.tw','$2y$10$RWBQaTK3slYg5gxZPZtk2O.Z1gzTXKxYgePZBpLxb0aHyOhz7z.ta','professor','b2cfKtXmrxrCBVSVOwsS5McuFjQZF47rC148NBgrBjqpLKVqEVB6jwsPlWYD','2017-04-02 04:44:48','2017-04-02 04:44:48'),(7,'chen','chen@thu.edu.tw','$2y$10$iqX57QRZx0UR10vKl/.jwOvlKrAMrPowpzfTcKjd5TPqpEYKqRmVu','student','xkNfUV3HT4Tt1pr5XeSggPL4bwYmQjlPUYDpfnKZ5lrY8xiX0PHe9pNx4yh4','2017-04-02 05:50:50','2017-04-02 05:50:50'),(8,'阮美*','chi1@thu.edu.tw','$2y$10$h2HK4QOq8w/bipCKUyttke2QO1QtDylZJQA2E.jdcRPDj6NVR0gXC','professor',NULL,'2017-04-06 20:08:27','2017-04-06 20:08:27'),(9,'李建*','chi2@thu.edu.tw','$2y$10$S1dDgr.ZcXWsTTw.SZq2F.rY9P940UVv5T7jnIh7O9Fo9i4Kusi9C','professor',NULL,'2017-04-06 20:08:48','2017-04-06 20:08:48'),(10,'鍾曉*','chi3@thu.edu.tw','$2y$10$YUtUgi6ukkHI7WqBh6rj3OHSI67MgTgrFEWaHthI8o5f77HVtUVI6','professor',NULL,'2017-04-06 20:09:27','2017-04-06 20:09:27'),(11,'左家*','chi4@thu.edu.tw','$2y$10$A5HSJ2FuJwhz7.nQLBJzW./.Vy1HjVqv/T7Ar5aWKUQB.7rK5le5a','professor',NULL,'2017-04-06 20:09:47','2017-04-06 20:09:47'),(12,'陳筱*','chi5@thu.edu.tw','$2y$10$eASEZD0XsCpWsESekrfcvOvAUHw2.nZtuGCvD24t8p31NzcNOnlru','professor',NULL,'2017-04-06 20:10:26','2017-04-06 20:10:26'),(13,'陳慶*','chi6@thu.edu.tw','$2y$10$LynV.zGkNph2mtP/A5uXVuc1xAKlUuOwLjUDWDTlaxW6MdIbcGMDS','professor',NULL,'2017-04-06 20:10:56','2017-04-06 20:10:56'),(14,'劉榮*','chi7@thu.edu.tw','$2y$10$KH.5scXvLG4FKM2YZJQhUuNdCFE6GVip7I73vJ4Ztt1D5pLXWcug6','professor',NULL,'2017-04-06 20:11:43','2017-04-06 20:11:43'),(15,'周玟*','chi8d@thu.edu.tw','$2y$10$ZLhlZNMjU0R30FxIxY1N9.zyHCZpfe6baJmdFlrEu5UqkngWIPcaG','professor',NULL,'2017-04-06 20:11:59','2017-05-14 05:13:51'),(16,'陳*潔','f1026125@thu.edu.tw','$2y$10$7PIRpS5FSVkwD7fqhQRoNeow.8cOoOys/DdjvFwS1k.sN5TOQT30W','student','tns8SPsMYr9DNpgn8Q7rgsj3fna9WbtEjYCBVUL7vZSz2GlB9NdT31AdJXAK','2017-05-14 05:19:05','2017-05-15 16:04:36'),(17,'陳*綸','f1026120@thu.edu.tw','$2y$10$Ey2p78eRRFj1H9fEFbLGMelbhrzU59aamYDj06cW5BD.dqLc5ohBO','student','eaZgzNG9GSTY0NQUXyYKZLpdltcld5WvPlpa6IqMCLwH6SU8rXtDXHT45Jo5','2017-05-14 05:19:46','2017-05-15 16:03:55'),(18,'陳*任','f1026121@thu.edu.tw','$2y$10$k5GVauCnNd5jtKXikYOIoudr1T.53BJa6e.HQtQbE0tDjWirGHaFy','student','cYNl7BULA94tSMRaxdKHUdRPTsVxNztEF3NjpG5lvlJZc7vUjmZYiSAeVpFo','2017-05-14 05:20:05','2017-05-14 13:42:31'),(19,'林*毅','f1026115@thu.edu.tw','$2y$10$76voiOkXGdMREDFuT1ynY.agZGkIZuxPZX73pI9/ZoPeJEKvqG6vi','student','UX3ozr8CWb53QSyRFNS6tYpcmQvpTmW0U578Kj2H7sWactEzsgeemvTlaqWu','2017-05-14 05:20:30','2017-05-14 13:42:38'),(20,'王*榮','f1026128@thu.edu.tw','$2y$10$993hOzqIAkR9XSfCkZt7Te0GvuDzaZMYdd6k.s3kWNCxpRBcC6Cou','student','MAYZb1WyppsF8r7FQVh9Le8zTX1ppbnkwyeanCMokBL5c7E4VXrBOgvYboME','2017-05-14 05:20:49','2017-05-14 13:42:45'),(21,'admin1','admin1@thu.edu.tw','$2y$10$dGoOvnkwnExjNkH/GAK6XeXi2hcuyYYqxCHU.j4BPjK9ETgEFtkFm','authority','wZjopIXdolJEntGwTbgcQtCA15FkS2atF18NEba7RF95VZJKNofnpU9NKSOa','2017-05-14 15:18:49','2017-05-18 23:47:54'),(23,'梁*尹','S03420242@thu.edu.tw','$2y$10$bHZUkDqQkFZrMZp7i8UxreKQ1qe/LqC/FkBkJtFPhk9Flh.FHQrzS','student','3cxWDbzbKG5tZ4FQVCe1dXhj9xi3SWQzsJGoraRSAGySy3iqHyoPN4CbN0eR','2017-05-15 05:17:45','2017-05-15 05:17:45'),(24,'許*緯','f1026114@thu.edu.tw','$2y$10$rTSwR0..D6gdxLiIc3TO7e5MByduXe4G4bMQ8nifo0F7J/6gitTZO','student',NULL,'2017-05-15 06:40:16','2017-05-15 06:40:16'),(28,'張*原','f1026109@thu.edu.tw','$2y$10$SQa77w6cQyW2Llz52NxKk.t7TksnQBszx/74IbCOp8.svD7cZlIby','student','ygt2TVOJDgQapyDfEQ7UeUAKCaUzER1t6iyCf41yOROQujeH5mnJF6MPME8D','2017-05-15 09:19:33','2017-05-15 09:19:33'),(60,'admin2','admin2@thu.edu.tw','$2y$10$0MshXyR.7bRaYCzWVZ5wyuZLSu8/HSVgJZ863uZzpKJ1g6ZYBgtoC','authority',NULL,'2017-05-19 14:18:14','2017-05-19 14:18:14'),(61,'廖啟*','liaw@thu.edu.tw','$2y$10$WFL/VkH5eHkUxdTP80DHL.CaqSY9BODQ7SUaul3ka8MjD0jG02vJO','professor',NULL,'2017-05-20 02:14:46','2017-05-20 02:14:46'),(62,'羅文*','winston@thu.edu.tw','$2y$10$.LAGg87wEf4nl13HIFNire08yhdvbyIFbD/b97yeSiABuHyvyJ4Oi','professor',NULL,'2017-05-20 02:16:15','2017-05-20 02:16:26'),(63,'柯佳*','pess@thu.edu.tw','$2y$10$VIk5rNNpvg3TwtksMcjQgu6NPsk4bv1gtfL9C6M2hT3gIqthHCBnq','professor',NULL,'2017-05-20 02:24:17','2017-05-20 02:24:17'),(64,'許瑞*','rickysheu@thu.edu.tw','$2y$10$smhQ4Nns51Di.FJbqaoXAuQUCB45dpFbbtVtL15c8KZL/U3oSFLeq','professor',NULL,'2017-05-20 02:25:27','2017-05-20 02:25:27'),(65,'石志*','shihc@thu.edu.tw','$2y$10$/eNoxMoN12O5JC5tz8INbe/EnC9k3XF0ts2QjzEln2ZVvF/IKzatG','professor',NULL,'2017-05-20 02:34:06','2017-05-20 02:34:06'),(66,'黃宜*','yifung@thu.edu.tw','$2y$10$jWx7ry7jkUm2TXY8G529cuikhuMd6q.c9fbnBS4CpKvsDqZHcdu3K','professor',NULL,'2017-05-20 02:36:07','2017-05-20 02:36:07'),(67,'江輔*','admor@thu.edu.tw','$2y$10$llC0dZZTC.pnKGWiC1ZA7eymovBcMRH.IvxDAfm9u0gJeG2wNLhC.','professor',NULL,'2017-05-20 02:37:11','2017-05-20 02:37:11'),(68,'朱允*','juy@thu.edu.tw','$2y$10$3gJTO2URCAQuhWBm3mCGsOWM0r3Hut28CqGgm1exBlC5AwXDmM.2i','professor',NULL,'2017-05-20 02:39:58','2017-05-20 02:39:58'),(69,'蔡昇達','shasdkjfhs@thu.edu.tw','$2y$10$B/U.9kpWZ2GlwJyfWn.haO5p.0klgOursNpVqfYtZW9QK1yXQ5PTm','professor',NULL,'2017-05-20 02:48:46','2017-05-20 02:48:46'),(70,'林正*','cclin@thu.edu.tw','$2y$10$YNIYfTeW5uHp6LIxSqIeSOAKgA0rWIKCIq8Uzs2tmh47gvkRUdbF6','professor',NULL,'2017-05-20 02:58:07','2017-05-20 02:58:07');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-20 15:12:01
